main()
{
    int a;
    int b;
    b = 10;
    a = 20;
}
